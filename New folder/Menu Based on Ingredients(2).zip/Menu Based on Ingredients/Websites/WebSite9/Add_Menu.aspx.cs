﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.IO;

public partial class Add_Menu : System.Web.UI.Page
{
    int Step = 1;
    SqlConnection con;
    

    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Username"] == null)
        {
            Response.Redirect("Home.aspx");
        }
        List<string> li = new List<string>();
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        String com = "Select name from Ingredients";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (!IsPostBack)//Without this other Listbox functionn wont work
        {
    

            foreach (DataRow r in dt.Rows)
            {

                li.Add(r["name"].ToString());

            }
            ListBox1.DataSource = li;


            ListBox1.DataBind();
        }
        con.Close();

    }
    protected void Add_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedItem != null)
        {
            int index = ListBox1.SelectedIndex;
           // if (ListBox2.Items.FindByText(ListBox1.SelectedItem.Value.ToString()) == null) 
            //This is used when u want to show all the elements in Listbox 1 and no two same elemets to be added in Listbox2

            ListBox2.Items.Add(ListBox1.SelectedItem.Value.ToString());
            ListBox1.Items.Remove(ListBox1.SelectedItem.Value.ToString());
            if (index > 0)
            {
                ListBox1.Items[index - 1].Selected = true;
            }
            else if (index == 0 && ListBox1.Items.Count > 0)
            {
                ListBox1.Items[0].Selected = true;
            }
        }

    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (edit_bool.Text == "true")
        {
            ListBox3.Items[Convert.ToInt32(edit_index.Text)].Text = TextBox2.Text;
            ListBox3.Items[Convert.ToInt32(edit_index.Text)].Value = TextBox2.Text;
            edit_bool.Text = "false";
            edit_index.Text = "-1";
            Up.Visible = true;
            Down.Visible = true;
            Button5.Visible = true;
            Edit.Visible = true;
        }
        else
        {
            Step = Convert.ToInt32(Label5.Text);
            if (TextBox2.Text != "")
            {
                // Label4.Text += Step + "." + TextBox2.Text + "<br />";
                ListBox3.Items.Add("- " + TextBox2.Text);
                TextBox2.Text = "";
                // Label4.Visible = true;
                Step = Step + 1; ;
                Label5.Text = Convert.ToString(Step);
            }
        }
            
      
    }
    protected void Button2_Click(object sender, EventArgs e)
    {

    }

    protected void Remove_Click(object sender, EventArgs e)
    {
        if (ListBox2.SelectedItem != null)
        {
                int index = ListBox2.SelectedIndex;
                
                ListBox1.Items.Add(ListBox2.SelectedItem.Value.ToString());
                ListBox2.Items.Remove(ListBox2.SelectedItem.Value.ToString());
                if (index > 0)
                 ListBox2.Items[index - 1].Selected= true;
                else if (index == 0 && ListBox2.Items.Count > 0)
                {
                    ListBox2.Items[0].Selected = true;
                }
                
        }

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        string ingredients = "";
        string steps ="" ;
        string Image_url="";
        string menu_name = TextBox1.Text;
        string folderPath = Server.MapPath("~/Images/");
        double Calories = 0;
      
        String com_calories;
        SqlCommand s;
       

        ListItemCollection li = new ListItemCollection();
        li = ListBox2.Items;

        //Ingredients to menu
        for (int i = 0; i < li.Count; i++)
        {
            if (i < li.Count - 1)
                ingredients += "" + li[i].Value + ",";
            else
                ingredients += "" + li[i].Value;
        }

        //Calories to menu
        for (int i = 0; i < li.Count; i++)
        {
           con.Open();
           com_calories = "Select Calories from Ingredients where name = " + "'" + li[i].Value + "'";
           s = new SqlCommand(com_calories, con);
           s.CommandText = com_calories;
           if (Session[li[i].Value] != null)
           {
               Calories = Calories + (Convert.ToDouble(Session[li[i].Value].ToString()) * Convert.ToDouble(s.ExecuteScalar()));
           }
           else
           {
               Calories = Calories + Convert.ToDouble(s.ExecuteScalar());
           }
           con.Close();
        }
                
        //Steps to menu
        li = ListBox3.Items;
        for (int i = 0; i < li.Count; i++)
        {
            if (i < li.Count - 1)
                steps += "" + li[i].Value + "<br />";
            else
                steps += "" + li[i].Value;
        }
        

        //Check whether Directory (Folder) exists.
        if (!Directory.Exists(folderPath))
        {
            //If Directory (Folder) does not exists. Create it.
            Directory.CreateDirectory(folderPath);
        }

        //Save the File to the Directory (Folder).
        FileUpload1.SaveAs(folderPath + Path.GetFileName(FileUpload1.FileName));
        Image_url = Path.GetFileName(FileUpload1.FileName);

        con.Open();
        string com = "Insert into Menu values(" + "'" + menu_name + "'" + "," + "'" + ingredients + "'" + "," + "'" + steps + "'" + "," + "'" + Image_url + "'," + "'" + Calories + "'" + ")";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        adpt = new SqlDataAdapter(com, con);
        adpt.InsertCommand = new SqlCommand(com, con);
        adpt.InsertCommand.ExecuteNonQuery();
        con.Close();
        Response.Redirect(Request.RawUrl);


    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (ListBox3.SelectedItem != null)
        {
            int index = ListBox3.SelectedIndex;
            
            ListBox3.Items.Remove(ListBox3.SelectedItem.Value.ToString());
            if (index > 0)
                ListBox3.Items[index - 1].Selected = true;
            else if (index == 0 && ListBox3.Items.Count > 0)
            {
                ListBox3.Items[0].Selected = true;
            }
                

        }
        
    }
    protected void Up_Click(object sender, EventArgs e)
    {
        
        
        if (ListBox3.SelectedItem != null)
        {
            string selected_value = ListBox3.SelectedItem.Value;
            string selected_text = ListBox3.SelectedItem.Text;
            string changed_value = "";
            string changed_text = "";
            if (ListBox3.Items.IndexOf(ListBox3.SelectedItem) > 0)
            {
                int index = ListBox3.Items.IndexOf(ListBox3.SelectedItem);
                //Text Changed
                changed_text = ListBox3.Items[index-1].Text.ToString();
                ListBox3.Items[index].Text = changed_text;
                ListBox3.Items[index - 1].Text = selected_text;
                
                //ValueChanged
                changed_value = ListBox3.Items[index - 1].Value;
                ListBox3.Items[index].Value = changed_value;
                ListBox3.Items[index - 1].Value = selected_value;

                //Selection Changed
                ListBox3.SelectedItem.Selected = false;
                ListBox3.Items[index - 1].Selected = true;
               // ListBox3.Items.Insert();
            }
        }
    }
    protected void Down_Click(object sender, EventArgs e)
    {
       
        if (ListBox3.SelectedItem != null)
        {
            string selected_value = ListBox3.SelectedItem.Value;
            string selected_text = ListBox3.SelectedItem.Text;
            string changed_value = "";
            string changed_text = "";
            if ((ListBox3.Items.IndexOf(ListBox3.SelectedItem) < ListBox3.Items.Count - 1) && (ListBox3.Items.IndexOf(ListBox3.SelectedItem) != -1))
            {
                int index = ListBox3.Items.IndexOf(ListBox3.SelectedItem);
                //Text Changed
                changed_text = ListBox3.Items[index + 1].Text.ToString();
                ListBox3.Items[index].Text = changed_text;
                ListBox3.Items[index + 1].Text = selected_text;

                //ValueChanged
                changed_value = ListBox3.Items[index + 1].Value;
                ListBox3.Items[index].Value = changed_value;
                ListBox3.Items[index + 1].Value = selected_value;

                //Selection Changed
                ListBox3.SelectedItem.Selected = false;
                ListBox3.Items[index + 1].Selected = true;
                // ListBox3.Items.Insert();
            }
        }
        

    }
    protected void Edit_Click(object sender, EventArgs e)
    {
        

        if (ListBox3.SelectedItem != null)
        {
            edit_index.Text = Convert.ToString(ListBox3.SelectedIndex);
            TextBox2.Text = ListBox3.SelectedItem.Text;
            edit_bool.Text = "true";
            Up.Visible = false;
            Down.Visible = false;
            Button5.Visible = false;
            Edit.Visible = false;
        }
   

    }

    protected void Button6_Click(object sender, EventArgs e)
    {
        Label8.Visible = true;
        TextBox3.Visible = true;
        Button7.Visible = true;
        Label8.Text =ListBox2.SelectedItem.Text;
        if (Session[Label8.Text]  == null)
        {
            TextBox3.Text = "1";
        }
        else
        {
            TextBox3.Text = Session[Label8.Text].ToString();
        }
        
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        Label8.Visible = false;
        TextBox3.Visible = false;
        Button7.Visible = false;
        Session[Label8.Text] = TextBox3.Text;
    }
}