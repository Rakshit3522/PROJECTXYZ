﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;

public partial class Ingredients : System.Web.UI.Page
{
    String value;
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        value = Request.QueryString["value"];
        Label2.Text = value;
        if(value!=null)
        {
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        String com = "Select url from Ingredients where name = "+"'"+value+"'";
        SqlCommand s = new SqlCommand(com,con);
        s.CommandText = com;
        Image1.Attributes["src"] = "Images/" + Convert.ToString(s.ExecuteScalar());
        com = "Select Calories from Ingredients where name = " + "'" + value + "'";
        s = new SqlCommand(com, con);
        s.CommandText = com;
        Label5.Text = Convert.ToString(s.ExecuteScalar()) + " (per Gram)";
        con.Close();
        con.Dispose();
        }
    }
}