﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class Menu_Data : System.Web.UI.Page
{
    string name;
    SqlConnection con;
    protected void Page_Load(object sender, EventArgs e)
    {
        name = Request.QueryString["name"];
        Label1.Text = name;
        if (name != null)
        {
            con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
            con.Open();
            String com = "Select * from Menu where name = " + "'" + name + "'";
            SqlCommand s = new SqlCommand(com, con);
         //   s.CommandText = com;
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            DataRow dr = dt.Rows[0];
            Image1.Attributes["src"] = "Images/" + dr["Image_url"].ToString();
            Label3.Text = dr["Ingredients"].ToString();
            Label5.Text = dr["Steps"].ToString();
            Label7.Text = dr["Calories"].ToString();
            con.Close();
            con.Dispose();
        }
    }
}