﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.SessionState;

public partial class MasterPage : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Username"] == null)
        {
            LinkButton6.Visible = false;
            LinkButton11.Visible = false;
            LinkButton17.Visible = false;
        }
        else {
            LinkButton6.Visible = true;
            LinkButton11.Visible = true;
            LinkButton16.Visible = false;
            LinkButton17.Visible = true;
        }

    }
    protected void LinkButton3_Click(object sender, EventArgs e)
    {
       
        Response.Redirect("Ingredients.aspx");
        
    }
    protected void LinkButton2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Menu.aspx");
        
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Home.aspx");
        
    }
    protected void LinkButton4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Admin_Login.aspx");
       
         
    }
    protected void LinkButton17_Click(object sender, EventArgs e)
    {
        HttpContext.Current.Session["Username"] = null;
        Response.Redirect(Request.RawUrl);
    }
}
