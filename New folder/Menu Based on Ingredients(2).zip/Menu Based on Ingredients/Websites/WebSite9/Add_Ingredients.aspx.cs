﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Data.SqlClient;
using System.Configuration; 

public partial class Add_Ingredients : System.Web.UI.Page
{
    SqlConnection con;
    SqlDataAdapter adpt;
      
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Username"] == null)
        {
            Response.Redirect("Home.aspx");
        }
        

        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);

    }
    protected void button1_Click(object sender, EventArgs e)
    {
        string folderPath = Server.MapPath("~/Images/");
        string calories = TextBox2.Text;

        //Check whether Directory (Folder) exists.
        if (!Directory.Exists(folderPath))
        {
            //If Directory (Folder) does not exists. Create it.
            Directory.CreateDirectory(folderPath);
        }

        //Save the File to the Directory (Folder).
        FileUpload1.SaveAs(folderPath + Path.GetFileName(FileUpload1.FileName));

        Label3.Text = Path.GetFileName(FileUpload1.FileName);
        con.Open();
        string com = "Insert into Ingredients values(" + "'" + TextBox1.Text + "'"+"," + "'" + Label3.Text+ "'," +"'"+calories+"'"+")";
        adpt = new SqlDataAdapter(com, con);
        adpt.InsertCommand = new SqlCommand(com, con);
        adpt.InsertCommand.ExecuteNonQuery();
        Response.Redirect(Request.RawUrl);
    }
}