﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;


public partial class _Default : System.Web.UI.Page
{
    SqlConnection con;
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (HttpContext.Current.Session["Username"] == null)
        {
            Response.Redirect("Home.aspx");
        }
        
        List<string> li = new List<string>();
        con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        String com="Select name from Ingredients";
        SqlDataAdapter adpt = new SqlDataAdapter(com, con);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (!IsPostBack)//Without this other Listbox functionn wont work
        {
            foreach (DataRow r in dt.Rows)
            {

                li.Add(r["name"].ToString());

            }
            ListBox1.DataSource = li;


            ListBox1.DataBind();
        }
        con.Close();


    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if(ListBox1.SelectedItem !=null){

        string s= ListBox1.SelectedItem.Text;
     //   Label1.Visible = true;
        Label1.Text = s;
        iframe1.Attributes["src"] = "Ingredients_data.aspx?value="+ Server.UrlEncode(s);
        
        }
        else
        Response.Redirect(Request.RawUrl);

    }
    protected void CheckBox1_CheckedChanged(object sender, EventArgs e)
    {
       
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text != null)
        {
            if (HttpContext.Current.Session["Username"] == null)
            {
                Response.Redirect("Home.aspx");
            }
            List<string> li = new List<string>();
            con.Open();
            String com = "Select name from Ingredients where name like " + "'%" + TextBox1.Text + "%'";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            DataTable dt = new DataTable();
            adpt.Fill(dt);
            foreach (DataRow r in dt.Rows)
            {

                li.Add(r["name"].ToString());

            }
            ListBox1.DataSource = li;
            ListBox1.DataBind();



        }
        else
            Response.Redirect(Request.RawUrl);

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
       
        iframe1.Attributes["src"] = "Add_Ingredients.aspx";

    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (ListBox1.SelectedItem != null)
        {

            string s = ListBox1.SelectedItem.Text;
            con.Open();
            string com = "delete from Ingredients where name="+"'"+ s+"'";
            SqlDataAdapter adpt = new SqlDataAdapter(com, con);
            adpt.DeleteCommand = new SqlCommand(com, con);
            adpt.DeleteCommand.ExecuteNonQuery();
            con.Close();
            Response.Redirect(Request.RawUrl);
           
        }
       
    }
}