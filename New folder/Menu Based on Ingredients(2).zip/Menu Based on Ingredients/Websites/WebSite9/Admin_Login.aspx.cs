﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Admin_Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

        if (HttpContext.Current.Session["Username"] != null)
        {
            Response.Redirect("Home.aspx");
        }

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString);
        con.Open();
        String com = "SELECT * from Admin where Username=@Username and Password=@Password";
        SqlDataAdapter adpt = new SqlDataAdapter(com,con);

        adpt.SelectCommand.Parameters.AddWithValue("@Username", TextBox1.Text);
        adpt.SelectCommand.Parameters.AddWithValue("@Password", TextBox2.Text);
        DataTable dt = new DataTable();
        adpt.Fill(dt);
        if (dt.Rows.Count == 1)
        {
            HttpContext.Current.Session["Username"] = TextBox1.Text;
            Response.Redirect("Home.aspx");
        }
        else 
        {
            Label3.Text = "Incorrect Username or password";
            Label3.Visible = true;
        
        }

       
    }
}